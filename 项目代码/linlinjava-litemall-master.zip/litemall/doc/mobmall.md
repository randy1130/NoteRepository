# 5 litemall轻商城

litemall轻商城，是商城移动版本。

技术：

* 轻商城前端，即litemall-vue模块
  * vue-cli3 
  * Vue + Vue-router + Vant + Sass
  * axios
  * fastclick
  * babel-polyfill
  * @xkeshi/vue-countdown
  * Vant
* 轻商城后端，即litemall-wx-api模块，也就是和小商城后端是一样的。
  * Spring Boot 2.x
  * Spring MVC
  * [weixin-java-tools](https://gitee.com/binary/weixin-java-tools)


## 5.1 litemall-wx-api

可以阅读3.1

## 5.2 litemall-vue

这里的代码基于[vant--mobile-mall](https://github.com/qianzhaoy/vant--mobile-mall)

文档未完成。
