import Editor from './editor.vue';
export default Editor;
