import Fullscreen from './fullscreen.vue';
export default Fullscreen;
