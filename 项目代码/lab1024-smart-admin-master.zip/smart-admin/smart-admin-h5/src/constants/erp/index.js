import contactCompany from './contact-company';

export default {
  ...contactCompany
};

