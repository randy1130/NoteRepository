package net.lab1024.smartadmin.constant;
/**
 * smart initDefines 项 常量
 *
 * @author listen
 * @date 2018/02/10 14:29
 */
public class SmartReloadTagConst {

    /**
     * 系统环境设置 DEMO
     */
    public static final String SYSTEM_CONFIG = "system_config";


}
