package net.lab1024.smartadmin.util.excel;

/**
 * @author zhuoda
 */
public enum SmartExcelFileType {
    XLS,
    XLSX

}
