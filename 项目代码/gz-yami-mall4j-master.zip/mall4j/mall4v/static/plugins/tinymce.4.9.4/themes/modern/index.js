// Exports the "modern" theme for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/themes/modern')
//   ES2015:
//     import 'tinymce/themes/modern'
require('./theme.js');