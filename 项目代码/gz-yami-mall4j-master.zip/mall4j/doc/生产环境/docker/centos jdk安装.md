（1）安装JDK

安装JDK,如果没有java-1.8.0-openjdk-devel就没有javac命令

```bash
yum  install  java-1.8.0-openjdk   java-1.8.0-openjdk-devel     
```

