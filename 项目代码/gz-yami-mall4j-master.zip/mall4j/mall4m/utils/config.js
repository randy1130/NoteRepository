var domain = "http://127.0.0.1:8086"; //统一接口域名，测试环境

exports.domain = domain;
