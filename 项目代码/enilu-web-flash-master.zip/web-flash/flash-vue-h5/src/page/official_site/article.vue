<template>
  <div>
    <x-header :title="article.title"></x-header>
    <meArticle :article="article"></meArticle>
    <footMenu></footMenu>
  </div>
</template>
<script src="./article.js"></script>
<style scoped>

</style>
