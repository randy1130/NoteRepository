# flash-vue-h5
基于web-flash后台管理cms模块的手机端内容展示系统

## 演示地址
http://47.104.84.62:8080/mobile/#/index
## Build Setup

``` bash
# install dependencies
npm install
or 
npm install --registry=https://registry.npm.taobao.org

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

```
访问：http:/localhost:8088/mobile/#/index
