package cn.enilu.flash.dao.system;

import cn.enilu.flash.bean.entity.system.FileInfo;
import cn.enilu.flash.dao.BaseRepository;

public interface FileInfoRepository extends BaseRepository<FileInfo, Long> {
}
