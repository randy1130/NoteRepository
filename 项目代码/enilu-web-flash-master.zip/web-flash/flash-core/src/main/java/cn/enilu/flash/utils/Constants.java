package cn.enilu.flash.utils;

/**
 * 系统常量
 */
public interface Constants {
    /**
     * 默认的系统用户id
     */
    long SYSTEM_USER_ID = -1;


    String SEPARATOR = ";;;";
}
