<template>
  <div class="app-container">
    <div class="block">
      <iframe src="http://flash-api.enilu.cn/swagger-ui.html" width="100%" height="768px" frameborder="0" scrolling="auto"></iframe>


    </div>

  </div>
</template>


<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/common.scss";
</style>

