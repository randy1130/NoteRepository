<template>
  <div class="app-container">
    <div class="block">
      <iframe src="https://enilu.gitee.io/web-flash" width="100%" height="768px" frameborder="0" scrolling="auto"></iframe>


    </div>

  </div>
</template>


<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/common.scss";
</style>

