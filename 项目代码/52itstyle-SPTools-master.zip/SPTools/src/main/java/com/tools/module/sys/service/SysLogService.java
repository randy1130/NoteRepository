package com.tools.module.sys.service;

import com.tools.common.model.Result;
import com.tools.module.sys.entity.SysLog;

public interface SysLogService {

    Result list(SysLog log);
}
